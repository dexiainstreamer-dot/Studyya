
import { useState, useEffect, useRef, useCallback } from 'react';
import { TimerMode } from '../types';

export const useTimer = (durations: { [key in TimerMode]: number }, onComplete: (mode: TimerMode) => void) => {
    const [mode, setMode] = useState<TimerMode>(TimerMode.Work);
    const [timeLeft, setTimeLeft] = useState(durations[TimerMode.Work] * 60);
    const [isActive, setIsActive] = useState(false);
    const [pomodoroCount, setPomodoroCount] = useState(0);

    const intervalRef = useRef<number | null>(null);
    const audioRef = useRef<AudioContext | null>(null);

    const playSound = useCallback(() => {
        if (!audioRef.current) {
            audioRef.current = new (window.AudioContext || (window as any).webkitAudioContext)();
        }
        const oscillator = audioRef.current.createOscillator();
        const gainNode = audioRef.current.createGain();
        oscillator.connect(gainNode);
        gainNode.connect(audioRef.current.destination);
        oscillator.type = 'sine';
        oscillator.frequency.setValueAtTime(440, audioRef.current.currentTime);
        gainNode.gain.setValueAtTime(0.5, audioRef.current.currentTime);
        gainNode.gain.exponentialRampToValueAtTime(0.0001, audioRef.current.currentTime + 1);
        oscillator.start(audioRef.current.currentTime);
        oscillator.stop(audioRef.current.currentTime + 1);
    }, []);

    const switchMode = useCallback((newMode: TimerMode, autoStartNext = false) => {
        setIsActive(autoStartNext);
        setMode(newMode);
        setTimeLeft(durations[newMode] * 60);
    }, [durations]);

    useEffect(() => {
        // This effect resets the timer if the durations are changed in settings.
        // It's set to only depend on `durations` to not interfere with mode switching.
        setTimeLeft(durations[mode] * 60);
        setIsActive(false);
    }, [durations]);
    
    useEffect(() => {
        if (isActive && timeLeft > 0) {
            intervalRef.current = window.setInterval(() => {
                setTimeLeft((prevTime) => prevTime - 1);
            }, 1000);
        } else if (timeLeft === 0 && isActive) {
            playSound();
            onComplete(mode);
            if (mode === TimerMode.Work) {
                const newPomodoroCount = pomodoroCount + 1;
                setPomodoroCount(newPomodoroCount);
                if (newPomodoroCount % 4 === 0) {
                    switchMode(TimerMode.LongBreak, true);
                } else {
                    switchMode(TimerMode.ShortBreak, true);
                }
            } else {
                switchMode(TimerMode.Work, true);
            }
        }
        return () => {
            if (intervalRef.current) {
                clearInterval(intervalRef.current);
            }
        };
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [isActive, timeLeft, mode, pomodoroCount, onComplete, playSound, switchMode]);
    

    const toggleTimer = () => {
        setIsActive(!isActive);
    };

    const resetTimer = () => {
        setIsActive(false);
        setTimeLeft(durations[mode] * 60);
    };

    const progress = ((durations[mode] * 60 - timeLeft) / (durations[mode] * 60)) * 100;

    return {
        mode,
        timeLeft,
        isActive,
        progress,
        toggleTimer,
        resetTimer,
        setMode: switchMode,
    };
};
