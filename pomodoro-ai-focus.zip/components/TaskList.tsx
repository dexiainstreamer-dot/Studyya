
import React, { useState } from 'react';
import { Task, PriorityLevel } from '../types';
import { Theme } from '../constants';
import { PlusIcon, TrashIcon, CheckIcon, GripVerticalIcon, FlagIcon } from './icons/Icons';

interface TaskListProps {
    tasks: Task[];
    addTask: (text: string) => void;
    toggleTask: (id: string) => void;
    deleteTask: (id: string) => void;
    selectTask: (id: string) => void;
    currentTaskId: string | null;
    theme: Theme;
    reorderTasks: (draggedId: string, targetId: string) => void;
    updateTaskPriority: (id: string, priority: PriorityLevel) => void;
}

const PRIORITY_CLASSES: { [key in PriorityLevel]: { border: string; flag: string; } } = {
    [PriorityLevel.High]: { border: 'border-red-500', flag: 'text-red-500' },
    [PriorityLevel.Medium]: { border: 'border-orange-400', flag: 'text-orange-400' },
    [PriorityLevel.Low]: { border: 'border-blue-500', flag: 'text-blue-500' },
    [PriorityLevel.None]: { border: 'border-transparent', flag: 'text-gray-400 dark:text-gray-500 hover:text-gray-600 dark:hover:text-gray-300' },
};


const TaskItem: React.FC<{
    task: Task;
    onToggle: () => void;
    onDelete: () => void;
    onSelect: () => void;
    onUpdatePriority: (priority: PriorityLevel) => void;
    isCurrent: boolean;
    theme: Theme;
    onDragStart: React.DragEventHandler<HTMLLIElement>;
    onDragOver: React.DragEventHandler<HTMLLIElement>;
    onDrop: React.DragEventHandler<HTMLLIElement>;
    onDragEnd: React.DragEventHandler<HTMLLIElement>;
    onDragLeave: React.DragEventHandler<HTMLLIElement>;
    isBeingDragged: boolean;
    isDropTarget: boolean;
}> = ({ task, onToggle, onDelete, onSelect, onUpdatePriority, isCurrent, theme, onDragStart, onDragOver, onDrop, onDragEnd, onDragLeave, isBeingDragged, isDropTarget }) => {
    
    const dropTargetClasses = isDropTarget ? 'border-t-red-500' : 'border-t-transparent';
    const beingDraggedClasses = isBeingDragged ? 'opacity-40' : '';

    const cyclePriority = () => {
        const priorities = [PriorityLevel.None, PriorityLevel.Low, PriorityLevel.Medium, PriorityLevel.High];
        const currentIndex = priorities.indexOf(task.priority);
        const nextIndex = (currentIndex + 1) % priorities.length;
        onUpdatePriority(priorities[nextIndex]);
    };

    return (
        <li
            draggable={!task.completed}
            onDragStart={onDragStart}
            onDragOver={onDragOver}
            onDrop={onDrop}
            onDragEnd={onDragEnd}
            onDragLeave={onDragLeave}
            className={`flex items-center p-3 rounded-lg transition-all duration-200 border-l-4 ${PRIORITY_CLASSES[task.priority].border} ${isCurrent ? 'bg-black/10 dark:bg-white/10' : 'hover:bg-black/5 dark:hover:bg-white/5'} ${beingDraggedClasses} relative border-t-2 ${dropTargetClasses}`}
        >
            <div className={`mr-2 ${task.completed ? 'invisible' : 'cursor-grab active:cursor-grabbing text-gray-400 dark:text-gray-500'}`}>
                <GripVerticalIcon />
            </div>
            <button onClick={onToggle} className={`w-6 h-6 rounded-full border-2 flex-shrink-0 mr-4 flex items-center justify-center transition-colors ${task.completed ? `${theme.accentWork} border-transparent text-white` : 'border-gray-300 dark:border-gray-500'}`}>
                {task.completed && <CheckIcon />}
            </button>
            <span onClick={onSelect} className={`flex-grow cursor-pointer ${task.completed ? 'line-through text-gray-400 dark:text-gray-500' : ''}`}>
                {task.text}
            </span>
            <div className="flex items-center ml-4 space-x-2">
                <button onClick={cyclePriority} title="Cycle Priority" className={`transition-colors ${PRIORITY_CLASSES[task.priority].flag}`}>
                    <FlagIcon />
                </button>
                <button onClick={onDelete} className="text-gray-400 hover:text-red-500 transition-colors">
                    <TrashIcon />
                </button>
            </div>
        </li>
    );
}

const TaskList: React.FC<TaskListProps> = ({ tasks, addTask, toggleTask, deleteTask, selectTask, currentTaskId, theme, reorderTasks, updateTaskPriority }) => {
    const [newTaskText, setNewTaskText] = useState('');
    const [draggedItemId, setDraggedItemId] = useState<string | null>(null);
    const [dropTargetId, setDropTargetId] = useState<string | null>(null);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        addTask(newTaskText);
        setNewTaskText('');
    };

    const handleDragStart = (e: React.DragEvent<HTMLLIElement>, task: Task) => {
        if (task.completed) {
            e.preventDefault();
            return;
        }
        e.dataTransfer.setData('taskId', task.id);
        e.dataTransfer.effectAllowed = 'move';
        setDraggedItemId(task.id);
    };

    const handleDragOver = (e: React.DragEvent<HTMLLIElement>, task: Task) => {
        e.preventDefault();
        if (task.id !== draggedItemId) {
            setDropTargetId(task.id);
        }
    };

    const handleDragLeave = () => {
        setDropTargetId(null);
    };

    const handleDrop = (e: React.DragEvent<HTMLLIElement>, targetTask: Task) => {
        e.preventDefault();
        const draggedId = e.dataTransfer.getData('taskId');
        if (draggedId && draggedId !== targetTask.id) {
            reorderTasks(draggedId, targetTask.id);
        }
        setDraggedItemId(null);
        setDropTargetId(null);
    };

    const handleDragEnd = () => {
        setDraggedItemId(null);
        setDropTargetId(null);
    };
    
    return (
        <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm p-6 rounded-2xl shadow-lg w-full">
            <h2 className="text-xl font-bold mb-4">Tasks</h2>
            <form onSubmit={handleSubmit} className="flex items-center mb-4">
                <input
                    type="text"
                    value={newTaskText}
                    onChange={(e) => setNewTaskText(e.target.value)}
                    placeholder="Add a new task..."
                    className="flex-grow bg-gray-200/50 dark:bg-gray-700/50 border-none rounded-lg px-4 py-2 focus:ring-2 focus:ring-red-500 transition-colors"
                />
                <button type="submit" className={`ml-3 p-2 rounded-full text-white transition-colors ${theme.accentWork} hover:opacity-90`}>
                    <PlusIcon />
                </button>
            </form>
            <ul className="space-y-2">
                {tasks.map((task) => (
                    <TaskItem
                        key={task.id}
                        task={task}
                        onToggle={() => toggleTask(task.id)}
                        onDelete={() => deleteTask(task.id)}
                        onSelect={() => selectTask(task.id)}
                        onUpdatePriority={(priority) => updateTaskPriority(task.id, priority)}
                        isCurrent={currentTaskId === task.id}
                        theme={theme}
                        onDragStart={(e) => handleDragStart(e, task)}
                        onDragOver={(e) => handleDragOver(e, task)}
                        onDrop={(e) => handleDrop(e, task)}
                        onDragEnd={handleDragEnd}
                        onDragLeave={handleDragLeave}
                        isBeingDragged={draggedItemId === task.id}
                        isDropTarget={dropTargetId === task.id && draggedItemId !== task.id}
                    />
                ))}
            </ul>
        </div>
    );
};

export default TaskList;