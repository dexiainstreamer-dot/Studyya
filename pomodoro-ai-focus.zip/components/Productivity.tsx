import React, { useState, useMemo, useEffect } from 'react';
import { Task } from '../types';
import { Theme } from '../constants';
import { CloseIcon, CheckIcon } from './icons/Icons';

interface ProductivityProps {
    onClose: () => void;
    pomodoroHistory: { timestamp: number; duration: number }[];
    tasks: Task[];
    theme: Theme;
}

type ViewMode = 'daily' | 'weekly' | 'monthly';

const Productivity: React.FC<ProductivityProps> = ({ onClose, pomodoroHistory, tasks, theme }) => {
    const [viewMode, setViewMode] = useState<ViewMode>('daily');
    const [animate, setAnimate] = useState(false);

    useEffect(() => {
        // Trigger animation on mount
        const timer = setTimeout(() => setAnimate(true), 100);
        return () => clearTimeout(timer);
    }, []);

    useEffect(() => {
        // Re-trigger animation when view mode changes
        setAnimate(false);
        const timer = setTimeout(() => setAnimate(true), 100);
        return () => clearTimeout(timer);
    }, [viewMode]);

    const completedTasks = useMemo(() => tasks.filter(t => t.completed && t.completedAt), [tasks]);

    const { chartData, totalMinutes, totalTasks, completedTasksForPeriod } = useMemo(() => {
        const now = new Date();
        const today = new Date(now.getFullYear(), now.getMonth(), now.getDate());
        let startDate = new Date(today);
        let labels: string[] = [];
        let numIntervals = 0;

        switch (viewMode) {
            case 'daily':
                numIntervals = 7;
                startDate.setDate(today.getDate() - (numIntervals - 1));
                labels = Array.from({ length: numIntervals }, (_, i) => {
                    const d = new Date(startDate);
                    d.setDate(startDate.getDate() + i);
                    return d.toLocaleDateString('en-US', { weekday: 'short' });
                });
                break;
            case 'weekly':
                numIntervals = 4;
                startDate = new Date(today);
                startDate.setDate(today.getDate() - (today.getDay() || 7) + 1 - ((numIntervals - 1) * 7)); // Start from the beginning of the week
                 labels = Array.from({ length: numIntervals }, (_, i) => `Week ${i + 1}`);
                break;
            case 'monthly':
                numIntervals = 6;
                startDate = new Date(today.getFullYear(), today.getMonth() - (numIntervals - 1), 1);
                labels = Array.from({ length: numIntervals }, (_, i) => {
                    const d = new Date(startDate);
                    d.setMonth(startDate.getMonth() + i);
                    return d.toLocaleDateString('en-US', { month: 'short' });
                });
                break;
        }

        const intervalData = Array(numIntervals).fill(0);
        
        pomodoroHistory.forEach(session => {
            const sessionDate = new Date(session.timestamp);
            if (sessionDate >= startDate) {
                let index = -1;
                if (viewMode === 'daily') {
                    index = Math.floor((sessionDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24));
                } else if (viewMode === 'weekly') {
                    index = Math.floor((sessionDate.getTime() - startDate.getTime()) / (1000 * 60 * 60 * 24 * 7));
                } else if (viewMode === 'monthly') {
                    index = (sessionDate.getFullYear() - startDate.getFullYear()) * 12 + (sessionDate.getMonth() - startDate.getMonth());
                }
                if (index >= 0 && index < numIntervals) {
                    intervalData[index] += session.duration;
                }
            }
        });

        const completedTasksForPeriod = completedTasks.filter(task => task.completedAt && task.completedAt >= startDate.getTime());

        const totalMinutes = pomodoroHistory.filter(p => p.timestamp >= startDate.getTime()).reduce((acc, curr) => acc + curr.duration, 0);
        const maxMinutes = Math.max(...intervalData, 1);
        
        return {
            chartData: intervalData.map((minutes, i) => ({
                label: labels[i],
                minutes,
                height: (minutes / maxMinutes) * 100,
            })),
            totalMinutes,
            totalTasks: completedTasksForPeriod.length,
            completedTasksForPeriod,
        };

    }, [viewMode, pomodoroHistory, completedTasks]);

    const accentColor = theme.accentWork.replace('bg-', 'text-');

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-2xl h-[80vh] bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex flex-col">
                <header className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-lg font-bold">Productivity Stats</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <CloseIcon />
                    </button>
                </header>

                <div className="flex-grow p-6 overflow-y-auto">
                    <div className="flex items-center justify-center space-x-2 mb-6 bg-gray-100 dark:bg-gray-700 p-1 rounded-full">
                        {(['daily', 'weekly', 'monthly'] as ViewMode[]).map(mode => (
                            <button
                                key={mode}
                                onClick={() => setViewMode(mode)}
                                className={`w-full px-4 py-2 text-sm font-semibold rounded-full transition-all capitalize ${
                                    viewMode === mode ? `${theme.accentWork} text-white shadow-md` : 'text-gray-600 dark:text-gray-300 hover:bg-gray-200 dark:hover:bg-gray-600'
                                }`}
                            >
                                {mode}
                            </button>
                        ))}
                    </div>

                    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
                        <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-center">
                            <div className={`text-3xl font-bold ${accentColor}`}>{Math.floor(totalMinutes / 60)}h {totalMinutes % 60}m</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">Total Focus Time</div>
                        </div>
                        <div className="bg-gray-100 dark:bg-gray-700 p-4 rounded-lg text-center">
                            <div className={`text-3xl font-bold ${accentColor}`}>{totalTasks}</div>
                            <div className="text-sm text-gray-600 dark:text-gray-400">Tasks Completed</div>
                        </div>
                    </div>

                    <div>
                        <h3 className="font-semibold mb-4">Focus Trend</h3>
                        <div className="h-48 flex items-end justify-around gap-2">
                            {chartData.map((data, index) => (
                                <div key={index} className="flex-1 flex flex-col items-center group">
                                    <div className={`w-full ${theme.accentWork} rounded-t-md transition-all duration-1000 ease-out`} style={{ height: animate ? `${data.height}%` : '0%' }}>
                                        <div className="relative opacity-0 group-hover:opacity-100 transition-opacity">
                                            <span className="absolute bottom-full left-1/2 -translate-x-1/2 mb-1 px-2 py-1 text-xs text-white bg-gray-900 rounded-md">
                                                {data.minutes} min
                                            </span>
                                        </div>
                                    </div>
                                    <span className="text-xs mt-2 text-gray-500">{data.label}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                    
                    <div className="mt-8">
                        <h3 className="font-semibold mb-4">Recently Completed</h3>
                        <ul className="space-y-2 max-h-48 overflow-y-auto">
                            {completedTasksForPeriod.length > 0 ? (
                                completedTasksForPeriod
                                    .sort((a, b) => (b.completedAt || 0) - (a.completedAt || 0))
                                    .map(task => (
                                <li key={task.id} className="flex items-center text-sm p-2 bg-gray-100 dark:bg-gray-700 rounded-lg">
                                    <CheckIcon size={14} className="text-green-500 mr-3 flex-shrink-0" />
                                    <span className="flex-grow line-through text-gray-500 dark:text-gray-400">{task.text}</span>
                                    <span className="text-xs text-gray-400 dark:text-gray-500">{new Date(task.completedAt!).toLocaleDateString()}</span>
                                </li>
                            ))) : (
                                <p className="text-sm text-center text-gray-500 py-4">No tasks completed in this period.</p>
                            )}
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Productivity;