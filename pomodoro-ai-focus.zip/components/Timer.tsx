
import React from 'react';
import { TimerMode } from '../types';
import { Theme, MODE_CONFIG } from '../constants';
import { PlayIcon, PauseIcon, RefreshIcon } from './icons/Icons';

interface TimerProps {
    theme: Theme;
    currentTaskName?: string;
    mode: TimerMode;
    timeLeft: number;
    isActive: boolean;
    progress: number;
    toggleTimer: () => void;
    resetTimer: () => void;
    setMode: (mode: TimerMode, autoStartNext?: boolean) => void;
}

const Timer: React.FC<TimerProps> = ({
    theme,
    currentTaskName,
    mode,
    timeLeft,
    isActive,
    progress,
    toggleTimer,
    resetTimer,
    setMode
}) => {
    const minutes = Math.floor(timeLeft / 60);
    const seconds = timeLeft % 60;

    const accentColor = mode === TimerMode.Work ? theme.accentWork : theme.accentBreak;

    const CIRCLE_SIZE = 280;
    const STROKE_WIDTH = 12;
    const RADIUS = (CIRCLE_SIZE - STROKE_WIDTH) / 2;
    const CIRCUMFERENCE = 2 * Math.PI * RADIUS;
    const strokeDashoffset = CIRCUMFERENCE - (progress / 100) * CIRCUMFERENCE;

    return (
        <div className="bg-white/50 dark:bg-gray-800/50 backdrop-blur-sm p-8 rounded-2xl shadow-lg w-full flex flex-col items-center mb-8">
            <div className="flex space-x-2 mb-6">
                {Object.values(TimerMode).map((m) => (
                    <button
                        key={m}
                        onClick={() => setMode(m)}
                        className={`px-4 py-2 text-sm font-semibold rounded-full transition-colors ${
                            mode === m
                                ? `${accentColor} text-white`
                                : 'bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600'
                        }`}
                    >
                        {MODE_CONFIG[m].label}
                    </button>
                ))}
            </div>

            <div className="relative w-[280px] h-[280px] mb-4">
                <svg className="w-full h-full" viewBox={`0 0 ${CIRCLE_SIZE} ${CIRCLE_SIZE}`}>
                    <circle
                        className="text-gray-300 dark:text-gray-600"
                        stroke="currentColor"
                        strokeWidth={STROKE_WIDTH}
                        fill="transparent"
                        r={RADIUS}
                        cx={CIRCLE_SIZE / 2}
                        cy={CIRCLE_SIZE / 2}
                    />
                    <circle
                        className={`transition-all duration-500 ${
                            mode === TimerMode.Work ? 'text-red-500' : 'text-blue-500'
                        }`}
                        stroke="currentColor"
                        strokeWidth={STROKE_WIDTH}
                        strokeDasharray={CIRCUMFERENCE}
                        strokeDashoffset={strokeDashoffset}
                        strokeLinecap="round"
                        fill="transparent"
                        r={RADIUS}
                        cx={CIRCLE_SIZE / 2}
                        cy={CIRCLE_SIZE / 2}
                        style={{ transform: 'rotate(-90deg)', transformOrigin: 'center' }}
                    />
                </svg>
                <div className="absolute inset-0 flex flex-col items-center justify-center">
                    <span className="text-6xl font-bold tracking-tighter">
                        {minutes.toString().padStart(2, '0')}:{seconds.toString().padStart(2, '0')}
                    </span>
                    <div className="h-6 mt-2 text-center">
                        {mode === TimerMode.Work && currentTaskName && (
                            <p className="text-sm text-gray-600 dark:text-gray-400 truncate max-w-[200px]">
                                Focusing on: {currentTaskName}
                            </p>
                        )}
                    </div>
                </div>
            </div>

            <div className="flex items-center space-x-4">
                <button onClick={resetTimer} className="p-3 rounded-full bg-gray-200 dark:bg-gray-700 text-gray-600 dark:text-gray-300 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors">
                    <RefreshIcon />
                </button>
                <button
                    onClick={toggleTimer}
                    className={`w-20 h-20 rounded-full flex items-center justify-center text-white shadow-lg transform hover:scale-105 transition-transform ${accentColor}`}
                >
                    {isActive ? <PauseIcon size={32} /> : <PlayIcon size={32} />}
                </button>
                 <div className="w-12 h-12"></div>
            </div>
        </div>
    );
};

export default Timer;
