
import React, { useState, useRef, useEffect, useCallback } from 'react';
import { ChatMessage, MessageSender, AiModel, GroundingChunk } from '../types';
import { AI_MODEL_CONFIG } from '../constants';
import { getAiResponse } from '../services/geminiService';
import { SendIcon, CloseIcon, GoogleIcon, BrainIcon } from './icons/Icons';

interface ChatbotProps {
    onClose: () => void;
}

const Chatbot: React.FC<ChatbotProps> = ({ onClose }) => {
    const [messages, setMessages] = useState<ChatMessage[]>([
        { id: 'initial', sender: MessageSender.Bot, text: "Hi! How can I help you stay focused today?" }
    ]);
    const [input, setInput] = useState('');
    const [isLoading, setIsLoading] = useState(false);
    const [model, setModel] = useState<AiModel>(AiModel.Flash);
    const [useGrounding, setUseGrounding] = useState(false);
    const messagesEndRef = useRef<HTMLDivElement>(null);

    const scrollToBottom = () => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    };

    useEffect(scrollToBottom, [messages]);

    const handleSend = useCallback(async () => {
        if (input.trim() === '' || isLoading) return;

        const userMessage: ChatMessage = { id: Date.now().toString(), sender: MessageSender.User, text: input };
        const loadingMessage: ChatMessage = { id: 'loading', sender: MessageSender.Bot, text: '', isLoading: true };
        
        setMessages(prev => [...prev, userMessage, loadingMessage]);
        setInput('');
        setIsLoading(true);

        const history = messages
            .filter(m => !m.isLoading)
            .map(m => ({
                role: m.sender === MessageSender.User ? 'user' : 'model',
                parts: [{ text: m.text }],
            }));
            
        const response = await getAiResponse(input, history, model, useGrounding);
        
        const botMessage: ChatMessage = {
            id: (Date.now() + 1).toString(),
            sender: MessageSender.Bot,
            text: response.text,
            sources: response.sources
        };

        setMessages(prev => [...prev.slice(0, -1), botMessage]);
        setIsLoading(false);
    }, [input, isLoading, messages, model, useGrounding]);

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-2xl h-[80vh] bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex flex-col">
                <header className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-lg font-bold">AI Assistant</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <CloseIcon />
                    </button>
                </header>

                <div className="flex-grow p-4 overflow-y-auto">
                    <div className="space-y-4">
                        {messages.map((msg) => (
                            <div key={msg.id} className={`flex items-start gap-3 ${msg.sender === MessageSender.User ? 'justify-end' : ''}`}>
                                {msg.sender === MessageSender.Bot && <div className="w-8 h-8 rounded-full bg-red-500 flex items-center justify-center text-white flex-shrink-0"><BrainIcon /></div>}
                                <div className={`max-w-md p-3 rounded-2xl ${msg.sender === MessageSender.User ? 'bg-red-500 text-white rounded-br-none' : 'bg-gray-200 dark:bg-gray-700 rounded-bl-none'}`}>
                                    {msg.isLoading ? (
                                        <div className="flex items-center space-x-2">
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                                            <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
                                        </div>
                                    ) : (
                                        <p className="whitespace-pre-wrap">{msg.text}</p>
                                    )}
                                     {msg.sources && msg.sources.length > 0 && (
                                        <div className="mt-3 pt-3 border-t border-gray-300 dark:border-gray-600">
                                            <h4 className="text-xs font-semibold mb-1">Sources:</h4>
                                            <div className="flex flex-col space-y-1">
                                                {msg.sources.map((source, index) => source.web && (
                                                    <a href={source.web.uri} target="_blank" rel="noopener noreferrer" key={index} className="text-xs text-blue-600 dark:text-blue-400 hover:underline truncate">
                                                        {source.web.title}
                                                    </a>
                                                ))}
                                            </div>
                                        </div>
                                    )}
                                </div>
                            </div>
                        ))}
                    </div>
                    <div ref={messagesEndRef} />
                </div>
                
                <footer className="p-4 border-t border-gray-200 dark:border-gray-700">
                    <div className="flex items-center justify-between mb-2 px-2">
                        <div className="flex items-center space-x-2">
                           {Object.values(AiModel).map(m => (
                               <button key={m} onClick={() => setModel(m)} className={`px-3 py-1 text-xs rounded-full ${model === m ? 'bg-red-500 text-white' : 'bg-gray-200 dark:bg-gray-600'}`}>
                                   {AI_MODEL_CONFIG[m].name}
                               </button>
                           ))}
                        </div>
                         <button onClick={() => setUseGrounding(!useGrounding)} className={`flex items-center space-x-2 px-3 py-1 text-xs rounded-full ${useGrounding ? 'bg-blue-500 text-white' : 'bg-gray-200 dark:bg-gray-600'}`}>
                             <GoogleIcon />
                             <span>Search</span>
                         </button>
                    </div>
                    <div className="relative">
                        <input
                            type="text"
                            value={input}
                            onChange={(e) => setInput(e.target.value)}
                            onKeyPress={(e) => e.key === 'Enter' && handleSend()}
                            placeholder="Ask anything..."
                            className="w-full bg-gray-100 dark:bg-gray-900 border-none rounded-full px-5 py-3 pr-12 focus:ring-2 focus:ring-red-500 transition"
                            disabled={isLoading}
                        />
                        <button onClick={handleSend} disabled={isLoading} className="absolute right-2 top-1/2 -translate-y-1/2 p-2 rounded-full bg-red-500 text-white hover:bg-red-600 transition disabled:bg-gray-400">
                            <SendIcon />
                        </button>
                    </div>
                </footer>
            </div>
        </div>
    );
};

export default Chatbot;
