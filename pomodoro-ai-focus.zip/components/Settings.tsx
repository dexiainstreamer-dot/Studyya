
import React from 'react';
import { TimerMode } from '../types';
import { THEMES, Theme, AMBIENT_SOUNDS } from '../constants';
import { CloseIcon, SunIcon, MoonIcon, VolumeIcon, VolumeMuteIcon, PlayIcon } from './icons/Icons';

interface SettingsProps {
    onClose: () => void;
    darkMode: boolean;
    setDarkMode: (value: boolean) => void;
    currentTheme: Theme;
    setTheme: (theme: Theme) => void;
    durations: { [key in TimerMode]: number };
    setDurations: (durations: { [key in TimerMode]: number }) => void;
    ambientSound: string | null;
    setAmbientSound: (src: string | null) => void;
    volume: number;
    setVolume: (volume: number) => void;
}

const Settings: React.FC<SettingsProps> = ({ onClose, darkMode, setDarkMode, currentTheme, setTheme, durations, setDurations, ambientSound, setAmbientSound, volume, setVolume }) => {

    const handleDurationChange = (mode: TimerMode, value: string) => {
        const minutes = parseInt(value, 10);
        if (!isNaN(minutes) && minutes > 0) {
            setDurations({ ...durations, [mode]: minutes });
        }
    };

    return (
        <div className="fixed inset-0 bg-black/50 backdrop-blur-sm z-50 flex items-center justify-center p-4">
            <div className="w-full max-w-md bg-white dark:bg-gray-800 rounded-2xl shadow-2xl flex flex-col">
                <header className="flex items-center justify-between p-4 border-b border-gray-200 dark:border-gray-700">
                    <h2 className="text-lg font-bold">Settings</h2>
                    <button onClick={onClose} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10">
                        <CloseIcon />
                    </button>
                </header>

                <div className="p-6 space-y-6 overflow-y-auto">
                    {/* Appearance */}
                    <div>
                        <h3 className="font-semibold mb-2">Appearance</h3>
                        <div className="flex items-center justify-between bg-gray-100 dark:bg-gray-700 p-3 rounded-lg">
                            <span>Dark Mode</span>
                            <button onClick={() => setDarkMode(!darkMode)} className="relative inline-flex items-center h-6 rounded-full w-11 transition-colors bg-gray-200 dark:bg-gray-600">
                                <span className={`inline-block w-4 h-4 transform bg-white rounded-full transition-transform ${darkMode ? 'translate-x-6' : 'translate-x-1'}`} />
                                <div className="absolute inset-0 flex items-center justify-around">
                                    <SunIcon size={12} className={`transition-opacity ${darkMode ? 'opacity-0' : 'opacity-100'}`} />
                                    <MoonIcon size={12} className={`transition-opacity ${darkMode ? 'opacity-100' : 'opacity-0'}`} />
                                </div>
                            </button>
                        </div>
                    </div>

                    {/* Theme */}
                    <div>
                        <h3 className="font-semibold mb-2">Theme</h3>
                        <div className="grid grid-cols-[repeat(auto-fit,minmax(140px,1fr))] gap-2">
                            {THEMES.map(theme => (
                                <button key={theme.name} onClick={() => setTheme(theme)} className={`p-3 rounded-lg text-left border-2 ${currentTheme.name === theme.name ? 'border-red-500' : 'border-transparent'} ${theme.bg} ${theme.primary}`}>
                                    <span className="font-semibold">{theme.name}</span>
                                    <div className="flex space-x-2 mt-2">
                                        <div className={`w-6 h-6 rounded-full ${theme.accentWork}`}></div>
                                        <div className={`w-6 h-6 rounded-full ${theme.accentBreak}`}></div>
                                    </div>
                                </button>
                            ))}
                        </div>
                    </div>

                    {/* Timer Durations */}
                    <div>
                        <h3 className="font-semibold mb-2">Timer Durations (minutes)</h3>
                        <div className="space-y-2">
                            <div className="flex items-center justify-between">
                                <label htmlFor="work-duration">Focus</label>
                                <input id="work-duration" type="number" value={durations.work} onChange={(e) => handleDurationChange(TimerMode.Work, e.target.value)} className="w-20 bg-gray-100 dark:bg-gray-700 rounded-md p-1 text-center" />
                            </div>
                            <div className="flex items-center justify-between">
                                <label htmlFor="short-break-duration">Short Break</label>
                                <input id="short-break-duration" type="number" value={durations.shortBreak} onChange={(e) => handleDurationChange(TimerMode.ShortBreak, e.target.value)} className="w-20 bg-gray-100 dark:bg-gray-700 rounded-md p-1 text-center" />
                            </div>
                            <div className="flex items-center justify-between">
                                <label htmlFor="long-break-duration">Long Break</label>
                                <input id="long-break-duration" type="number" value={durations.longBreak} onChange={(e) => handleDurationChange(TimerMode.LongBreak, e.target.value)} className="w-20 bg-gray-100 dark:bg-gray-700 rounded-md p-1 text-center" />
                            </div>
                        </div>
                    </div>
                    
                    {/* Ambient Sound */}
                    <div>
                        <h3 className="font-semibold mb-2">Ambient Sound</h3>
                        <div className="grid grid-cols-2 gap-2 mb-4">
                            {AMBIENT_SOUNDS.map(sound => {
                                const isSelected = ambientSound === sound.src;
                                return (
                                    <button
                                        key={sound.id}
                                        onClick={() => setAmbientSound(sound.src)}
                                        className={`p-3 rounded-lg text-left border-2 transition-colors flex items-center justify-between ${
                                            isSelected
                                                ? 'border-red-500 bg-red-500/20'
                                                : 'border-transparent bg-gray-100 dark:bg-gray-700 hover:bg-gray-200 dark:hover:bg-gray-600'
                                        }`}
                                    >
                                        <span className="font-semibold">{sound.name}</span>
                                        {isSelected && sound.src !== null && (
                                            <PlayIcon size={16} className="text-red-500" />
                                        )}
                                    </button>
                                );
                            })}
                        </div>
                        <div className="flex items-center space-x-3">
                            <button onClick={() => setVolume(volume > 0 ? 0 : 0.5)} className="text-gray-500 dark:text-gray-400">
                                {volume > 0 ? <VolumeIcon /> : <VolumeMuteIcon />}
                            </button>
                            <input
                                type="range"
                                min="0"
                                max="1"
                                step="0.01"
                                value={volume}
                                onChange={(e) => setVolume(parseFloat(e.target.value))}
                                className="w-full h-2 bg-gray-200 rounded-lg cursor-pointer dark:bg-gray-600 accent-red-500"
                            />
                             <span className="text-sm font-medium text-gray-600 dark:text-gray-400 w-12 text-center">
                                {Math.round(volume * 100)}%
                            </span>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default Settings;
