
import { TimerMode, AiModel } from './types';

export interface Theme {
    name: string;
    bg: string;
    primary: string;
    accentWork: string;
    accentBreak: string;
}

export const THEMES: Theme[] = [
    { name: 'Default', bg: 'bg-gray-100 dark:bg-gray-900', primary: 'text-gray-800 dark:text-gray-200', accentWork: 'bg-red-500', accentBreak: 'bg-blue-500' },
    { name: 'Forest', bg: 'bg-green-50 dark:bg-gray-800', primary: 'text-green-900 dark:text-green-100', accentWork: 'bg-emerald-500', accentBreak: 'bg-teal-500' },
    { name: 'Ocean', bg: 'bg-blue-50 dark:bg-gray-800', primary: 'text-blue-900 dark:text-blue-100', accentWork: 'bg-sky-500', accentBreak: 'bg-cyan-500' },
    { name: 'Sunset', bg: 'bg-orange-50 dark:bg-gray-800', primary: 'text-orange-900 dark:text-orange-100', accentWork: 'bg-amber-500', accentBreak: 'bg-yellow-500' },
    { name: 'Sakura', bg: 'bg-pink-50 dark:bg-gray-800', primary: 'text-pink-900 dark:text-pink-100', accentWork: 'bg-rose-500', accentBreak: 'bg-fuchsia-500' },
];

export const MODE_CONFIG = {
    [TimerMode.Work]: { label: 'Focus' },
    [TimerMode.ShortBreak]: { label: 'Short Break' },
    [TimerMode.LongBreak]: { label: 'Long Break' },
};

export const AI_MODEL_CONFIG = {
    [AiModel.FlashLite]: { name: 'Fast', description: 'Low-latency responses' },
    [AiModel.Flash]: { name: 'Balanced', description: 'Good for most questions' },
    [AiModel.Pro]: { name: 'Complex', description: 'Handles complex queries' },
};

export interface AmbientSound {
    id: string;
    name: string;
    src: string | null;
}

export const AMBIENT_SOUNDS: AmbientSound[] = [
    { id: 'none', name: 'None', src: null },
    { id: 'rain', name: 'Rain', src: 'https://cdn.pixabay.com/audio/2022/10/18/audio_1921f73449.mp3' },
    { id: 'forest', name: 'Forest', src: 'https://cdn.pixabay.com/audio/2022/08/04/audio_3507116752.mp3' },
    { id: 'whitenoise', name: 'White Noise', src: 'https://cdn.pixabay.com/audio/2023/07/20/audio_2d5343467f.mp3' },
    { id: 'rainforest', name: 'Rainforest', src: 'https://cdn.pixabay.com/audio/2022/10/21/audio_16cc07b41f.mp3' },
    { id: 'oceanwaves', name: 'Ocean Waves', src: 'https://cdn.pixabay.com/audio/2023/09/14/audio_51a30a21a2.mp3' },
];
