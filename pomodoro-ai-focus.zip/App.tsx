import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { TimerMode, Task, AiModel, PriorityLevel } from './types';
import { THEMES, Theme } from './constants';
import Timer from './components/Timer';
import TaskList from './components/TaskList';
import Chatbot from './components/Chatbot';
import Settings from './components/Settings';
import Productivity from './components/Productivity';
import { BotIcon, SettingsIcon, MaximizeIcon, MinimizeIcon, ChartBarIcon } from './components/icons/Icons';
import { useTimer } from './hooks/useTimer';

// Simple hook for persisting state to localStorage
const usePersistentState = <T,>(key: string, initialValue: T): [T, React.Dispatch<React.SetStateAction<T>>] => {
    const [state, setState] = useState<T>(() => {
        try {
            const item = window.localStorage.getItem(key);
            return item ? JSON.parse(item) : initialValue;
        } catch (error) {
            console.error(error);
            return initialValue;
        }
    });

    useEffect(() => {
        try {
            window.localStorage.setItem(key, JSON.stringify(state));
        } catch (error) {
            console.error(error);
        }
    }, [key, state]);

    return [state, setState];
};


const App: React.FC = () => {
    const [tasks, setTasks] = usePersistentState<Task[]>('tasks', []);
    const [pomodoroHistory, setPomodoroHistory] = usePersistentState<{ timestamp: number; duration: number }[]>('pomodoroHistory', []);
    const [currentTaskId, setCurrentTaskId] = useState<string | null>(null);
    const [isChatOpen, setChatOpen] = useState(false);
    const [isSettingsOpen, setSettingsOpen] = useState(false);
    const [isProductivityOpen, setProductivityOpen] = useState(false);
    const [ambientSound, setAmbientSound] = useState<string | null>(null);
    const [volume, setVolume] = useState(0.5);
    const ambientAudioRef = useRef<HTMLAudioElement>(null);
    const [isFullscreen, setIsFullscreen] = useState(false);

    const [darkMode, setDarkMode] = useState(() => {
        if (typeof window !== 'undefined') {
            return window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches;
        }
        return false;
    });
    
    const [theme, setTheme] = usePersistentState<Theme>('theme', THEMES[0]);
    const [timerDurations, setTimerDurations] = usePersistentState('timerDurations', {
        [TimerMode.Work]: 25,
        [TimerMode.ShortBreak]: 5,
        [TimerMode.LongBreak]: 15,
    });
    
    const handleTimerCompletion = useCallback((mode: TimerMode) => {
        if (mode === TimerMode.Work) {
             setPomodoroHistory(prev => [...prev, { timestamp: Date.now(), duration: timerDurations[TimerMode.Work] }]);
            if (currentTaskId) {
                toggleTask(currentTaskId, true);
                setCurrentTaskId(null);
            }
        }
    }, [currentTaskId, timerDurations, setPomodoroHistory]);

    const {
        mode,
        timeLeft,
        isActive,
        progress,
        toggleTimer,
        resetTimer,
        setMode,
    } = useTimer(timerDurations, handleTimerCompletion);

    useEffect(() => {
        const handleKeyDown = (event: KeyboardEvent) => {
            const target = event.target as HTMLElement;
            if (['INPUT', 'TEXTAREA'].includes(target.tagName)) {
                return;
            }

            switch (event.key.toLowerCase()) {
                case ' ':
                    event.preventDefault();
                    toggleTimer();
                    break;
                case 'r':
                    resetTimer();
                    break;
                case 's':
                    setSettingsOpen(true);
                    break;
                default:
                    break;
            }
        };

        window.addEventListener('keydown', handleKeyDown);
        return () => {
            window.removeEventListener('keydown', handleKeyDown);
        };
    }, [toggleTimer, resetTimer, setSettingsOpen]);

    useEffect(() => {
        document.documentElement.classList.toggle('dark', darkMode);
    }, [darkMode]);

    useEffect(() => {
        const audioEl = ambientAudioRef.current;
        if (!audioEl) return;

        if (ambientSound) {
            if (audioEl.src !== ambientSound) {
                audioEl.src = ambientSound;
            }
            audioEl.volume = volume;
            if (audioEl.paused) {
                audioEl.play().catch(error => {
                    console.log("Audio play prevented by browser. User interaction is required.", error);
                });
            }
        } else {
            audioEl.pause();
            audioEl.src = '';
        }
    }, [ambientSound, volume]);

    const toggleFullScreen = () => {
        if (!document.fullscreenElement) {
            document.documentElement.requestFullscreen();
        } else {
            if (document.exitFullscreen) {
                document.exitFullscreen();
            }
        }
    };

    useEffect(() => {
        const handleFullScreenChange = () => {
            setIsFullscreen(!!document.fullscreenElement);
        };

        document.addEventListener('fullscreenchange', handleFullScreenChange);

        return () => {
            document.removeEventListener('fullscreenchange', handleFullScreenChange);
        };
    }, []);
    
    const currentTask = useMemo(() => tasks.find(task => task.id === currentTaskId), [tasks, currentTaskId]);
    
    const addTask = (text: string) => {
        if (text.trim() === '') return;
        const newTask: Task = { id: Date.now().toString(), text, completed: false, priority: PriorityLevel.None };
        setTasks(prev => [...prev, newTask]);
    };

    const toggleTask = (id: string, forceComplete: boolean = false) => {
        setTasks(prev =>
            prev.map(task => {
                if (task.id === id) {
                    const isCompleted = forceComplete ? true : !task.completed;
                    return { 
                        ...task, 
                        completed: isCompleted,
                        completedAt: isCompleted ? Date.now() : undefined,
                    };
                }
                return task;
            })
        );
    };

    const deleteTask = (id: string) => {
        setTasks(prev => prev.filter(task => task.id !== id));
        if (currentTaskId === id) {
            setCurrentTaskId(null);
        }
    };

    const selectTask = (id: string) => {
        setCurrentTaskId(id);
    };

    const reorderTasks = useCallback((draggedId: string, targetId: string) => {
        setTasks(prev => {
            const tasksCopy = [...prev];
            const draggedItemIndex = tasksCopy.findIndex(task => task.id === draggedId);
            const targetItemIndex = tasksCopy.findIndex(task => task.id === targetId);

            if (draggedItemIndex === -1 || targetItemIndex === -1) {
                return prev;
            }
            
            const [draggedItem] = tasksCopy.splice(draggedItemIndex, 1);
            tasksCopy.splice(targetItemIndex, 0, draggedItem);
            
            return tasksCopy;
        });
    }, [setTasks]);
    
    const updateTaskPriority = useCallback((id: string, priority: PriorityLevel) => {
        setTasks(prev =>
            prev.map(task =>
                task.id === id ? { ...task, priority } : task
            )
        );
    }, [setTasks]);

    return (
        <div className={`min-h-screen w-full transition-colors duration-500 ${darkMode ? 'dark' : ''} ${theme.bg} ${theme.primary}`}>
            <div className="container mx-auto px-4 py-8 flex flex-col items-center max-w-2xl">
                <header className="w-full flex justify-between items-center mb-8">
                    <h1 className="text-2xl font-bold">Pomodoro AI Focus</h1>
                    <div className="flex items-center space-x-2">
                        <button onClick={toggleFullScreen} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors">
                            {isFullscreen ? <MinimizeIcon /> : <MaximizeIcon />}
                        </button>
                        <button onClick={() => setProductivityOpen(true)} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors">
                             <ChartBarIcon />
                        </button>
                        <button onClick={() => setChatOpen(true)} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors">
                             <BotIcon />
                        </button>
                        <button onClick={() => setSettingsOpen(true)} className="p-2 rounded-full hover:bg-black/10 dark:hover:bg-white/10 transition-colors">
                             <SettingsIcon />
                        </button>
                    </div>
                </header>

                <main className="w-full">
                    <Timer
                        theme={theme}
                        currentTaskName={currentTask?.text}
                        mode={mode}
                        timeLeft={timeLeft}
                        isActive={isActive}
                        progress={progress}
                        toggleTimer={toggleTimer}
                        resetTimer={resetTimer}
                        setMode={setMode}
                    />
                    <TaskList
                        tasks={tasks}
                        addTask={addTask}
                        toggleTask={toggleTask}
                        deleteTask={deleteTask}
                        selectTask={selectTask}
                        currentTaskId={currentTaskId}
                        theme={theme}
                        reorderTasks={reorderTasks}
                        updateTaskPriority={updateTaskPriority}
                    />
                </main>
            </div>
            <audio ref={ambientAudioRef} loop />
            {isChatOpen && <Chatbot onClose={() => setChatOpen(false)} />}
            {isProductivityOpen && <Productivity 
                onClose={() => setProductivityOpen(false)} 
                pomodoroHistory={pomodoroHistory} 
                tasks={tasks}
                theme={theme}
            />}
            {isSettingsOpen && (
                <Settings
                    onClose={() => setSettingsOpen(false)}
                    darkMode={darkMode}
                    setDarkMode={setDarkMode}
                    currentTheme={theme}
                    setTheme={setTheme}
                    durations={timerDurations}
                    // FIX: Pass the correct state setter 'setTimerDurations' for the 'setDurations' prop.
                    setDurations={setTimerDurations}
                    ambientSound={ambientSound}
                    setAmbientSound={setAmbientSound}
                    volume={volume}
                    setVolume={setVolume}
                />
            )}
        </div>
    );
};

export default App;
