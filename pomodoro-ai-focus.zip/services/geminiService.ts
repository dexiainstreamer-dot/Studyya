
import { GoogleGenAI } from "@google/genai";
import { AiModel } from '../types';

if (!process.env.API_KEY) {
    // This is a placeholder for environments where API_KEY is not set.
    // In a real build process, this should be handled properly.
    console.warn("API_KEY environment variable not set. Using a placeholder.");
    process.env.API_KEY = "YOUR_API_KEY";
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export const getAiResponse = async (
    prompt: string,
    history: { role: string; parts: { text: string }[] }[],
    model: AiModel,
    useGrounding: boolean
) => {
    try {
        if (useGrounding) {
            const response = await ai.models.generateContent({
                model: AiModel.Flash, // Grounding only with flash
                contents: [{ role: 'user', parts: [{ text: prompt }] }],
                config: {
                    tools: [{ googleSearch: {} }],
                },
            });
            return {
                text: response.text,
                sources: response.candidates?.[0]?.groundingMetadata?.groundingChunks || [],
            };
        }

        const chat = ai.chats.create({
            model: model,
            history,
            config: model === AiModel.Pro ? {
                thinkingConfig: { thinkingBudget: 32768 }
            } : {},
        });

        const response = await chat.sendMessage({ message: prompt });
        
        return {
            text: response.text,
            sources: [],
        };

    } catch (error) {
        console.error("Error getting AI response:", error);
        return {
            text: "Sorry, I encountered an error. Please try again.",
            sources: [],
        };
    }
};
