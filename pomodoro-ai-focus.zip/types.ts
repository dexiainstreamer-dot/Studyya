
export enum TimerMode {
    Work = 'work',
    ShortBreak = 'shortBreak',
    LongBreak = 'longBreak',
}

export enum PriorityLevel {
    None = 'none',
    Low = 'low',
    Medium = 'medium',
    High = 'high',
}

export interface Task {
    id: string;
    text: string;
    completed: boolean;
    priority: PriorityLevel;
    completedAt?: number;
}

export enum AiModel {
    Flash = 'gemini-2.5-flash',
    FlashLite = 'gemini-2.5-flash-lite',
    Pro = 'gemini-2.5-pro',
}

export enum MessageSender {
    User = 'user',
    Bot = 'bot',
}

export interface GroundingChunk {
    web?: {
        uri: string;
        title: string;
    }
}

export interface ChatMessage {
    id: string;
    sender: MessageSender;
    text: string;
    sources?: GroundingChunk[];
    isLoading?: boolean;
}